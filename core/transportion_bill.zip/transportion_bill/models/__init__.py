# -*- coding: utf-8 -*-

import res_partner
import delivery
import sale_order
import delivery_method_wizard