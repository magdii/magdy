# -*- coding: utf-8 -*-

from . import models
from . import sale_order
from . import vendor_bill
from . import res_partner
from . import stock_quant