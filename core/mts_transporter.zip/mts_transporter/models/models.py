# -*- coding: utf-8 -*-

from odoo import api, fields, models, tools, _
from odoo.exceptions import UserError
from odoo.tools import float_is_zero

class getJournal(models.Model):
    _inherit = "stock.move"

    def _prepare_account_move_line(self, qty, cost, credit_account_id, debit_account_id):
        """
        Generate the account.move.line values to post to track the stock valuation difference due to the
        processing of the given quant.
        """
        self.ensure_one()

        if self._context.get('force_valuation_amount'):
            valuation_amount = self._context.get('force_valuation_amount')
        else:
            if self.product_id.cost_method == 'average':
                valuation_amount = cost if self.location_id.usage == 'supplier' and self.location_dest_id.usage == 'internal' else self.product_id.standard_price
            else:
                valuation_amount = cost if self.product_id.cost_method == 'real' else self.product_id.standard_price
        # the standard_price of the product may be in another decimal precision, or not compatible with the coinage of
        # the company currency... so we need to use round() before creating the accounting entries.
        debit_value = self.company_id.currency_id.round(valuation_amount * qty)

        # check that all data is correct
        if self.company_id.currency_id.is_zero(debit_value):
            if self.product_id.cost_method == 'standard':
                raise UserError(_("The found valuation amount for product %s is zero. Which means there is probably a configuration error. Check the costing method and the standard price") % (self.product_id.name,))
            return []
        credit_value = debit_value

        if self.product_id.cost_method == 'average' and self.company_id.anglo_saxon_accounting:
            # in case of a supplier return in anglo saxon mode, for products in average costing method, the stock_input
            # account books the real purchase price, while the stock account books the average price. The difference is
            # booked in the dedicated price difference account.
            if self.location_dest_id.usage == 'supplier' and self.origin_returned_move_id and self.origin_returned_move_id.purchase_line_id:
                debit_value = self.origin_returned_move_id.price_unit * qty
            # in case of a customer return in anglo saxon mode, for products in average costing method, the stock valuation
            # is made using the original average price to negate the delivery effect.
            if self.location_id.usage == 'customer' and self.origin_returned_move_id:
                debit_value = self.origin_returned_move_id.price_unit * qty
                credit_value = debit_value
        partner_id = (self.picking_id.partner_id and self.env['res.partner']._find_accounting_partner(self.picking_id.partner_id).id) or False
        product_obj = self.env['stock.quant'].search([
            ('product_id', '=', self.product_id.id),
            ('location_id', '=', self.picking_id.picking_type_id.default_location_dest_id.id),
        ])
        new_price = 0.0
        new_quantity = 0.0
        if product_obj:
            for rec in product_obj:
                # new_price += rec.stock_unit_price
                new_price += rec.inventory_value
                new_quantity += rec.qty
        # product_price = new_price / len(product_obj)
        product_price = new_price / new_quantity
        print "new_price::::::: ", new_price
        print "new_quantity ::::::::::: ", new_quantity
        print "product_price ::::::::::: ", product_price
        debit_line_vals = {
            'name': self.name,
            'product_id': self.product_id.id,
            'quantity': qty,
            'product_uom_id': self.product_id.uom_id.id,
            'ref': self.picking_id.name,
            'partner_id': partner_id,
            'debit': product_price,
            'credit': 0,
            'account_id': debit_account_id,
        }
        credit_line_vals = {
            'name': self.name,
            'product_id': self.product_id.id,
            'quantity': qty,
            'product_uom_id': self.product_id.uom_id.id,
            'ref': self.picking_id.name,
            'partner_id': partner_id,
            'credit': product_price,
            'debit': 0,
            'account_id': credit_account_id,
        }
        new_price = 0.0
        new_quantity = 0.0
        res = [(0, 0, debit_line_vals), (0, 0, credit_line_vals)]
        if credit_value != debit_value:
            # for supplier returns of product in average costing method, in anglo saxon mode
            diff_amount = debit_value - credit_value
            price_diff_account = self.product_id.property_account_creditor_price_difference
            if not price_diff_account:
                price_diff_account = self.product_id.categ_id.property_account_creditor_price_difference_categ
            if not price_diff_account:
                raise UserError(_('Configuration error. Please configure the price difference account on the product or its category to process this operation.'))
            price_diff_line = {
                'name': self.name,
                'product_id': self.product_id.id,
                'quantity': qty,
                'product_uom_id': self.product_id.uom_id.id,
                'ref': self.picking_id.name,
                'partner_id': partner_id,
                'credit': diff_amount > 0 and diff_amount or 0,
                'debit': diff_amount < 0 and -diff_amount or 0,
                'account_id': price_diff_account.id,
            }
            res.append((0, 0, price_diff_line))
        return res

class LandedCostLine(models.Model):
    _inherit = 'stock.landed.cost.lines'

    @api.model
    def _get_landed_cost_product(self):
        return self.env['product.product'].search([('name', 'ilike', 'Freight')], limit=1)
        # product_id = self.env['product.product']
        # product_obj = product_id.search([('name', 'ilike', 'Freight')], limit=1)
        # print "<<<<<<<<<<<<<"
        # if product_obj:
        #     print "11111111111111"
        #     self.product_id = product_obj.id
        #     return self.product_id
        # else:
        #     print "555555555555"
        #     product = product_id.create({
        #         'name': 'Freight',
        #         'type': 'product',
        #         'categ_id': 1,
        #     })
        #     self.product_id = product.id
        #     return self.product_id




    product_id = fields.Many2one('product.product', 'Product', reuired=False, default=_get_landed_cost_product)
    analytic_account_id = fields.Many2one('account.analytic.account', string='Analytic Account')


class StockPicking(models.Model):
    _inherit = 'stock.picking'
    type = fields.Selection(string="Type",
                            selection=[('own_truck', 'Own Truck'),
                                       ('third_party_truck', 'Third Party Truck'),
                                       ('customer_truck', 'Customer Truck'), ],
                            required=False,
                            default='customer_truck', )
    freight_type = fields.Selection(string="Freight Type",
                                    selection=[('per_trip', 'Per Trip'),
                                               ('per_ton', 'Per Ton'), ],
                                    required=False, )
    Transporter_id = fields.Many2one(comodel_name="res.partner",
                                     string="Transporter",
                                     required=True,
                                     domain=[('transpoter', '=', True)])
    supplier_freight = fields.Float(string="Supplier Freight", )
    bill_reference = fields.Char(string="Bill Reference", )
    driver_name = fields.Char(string="Driver Name", )
    driver_mobile_no = fields.Char(string="Driver Mobile No", )
    vehicle_no = fields.Char(string="Vehicle No", )
    transporter_account_id = fields.Many2one(comodel_name="account.invoice",
                                             string="Transporter Bill",
                                             readonly=True, )
    is_third = fields.Boolean(compute="_compute_is_third")
    bill_state = fields.Selection(selection=[('draft','Draft'),
                                             ('proforma', 'Pro-forma'),
                                             ('proforma2', 'Pro-forma'),
                                             ('open', 'Open'),
                                             ('paid', 'Paid'),
                                             ('cancel', 'Cancelled'),
                                             ], related="transporter_account_id.state", )
    is_bill = fields.Boolean()
    is_landed = fields.Boolean()
    landed_cost_id = fields.Many2one('stock.landed.cost', string="Landed Cost", )


    @api.multi
    @api.depends('type')
    def _compute_is_third(self):
        if self.type == 'customer_truck':
           self.is_third=True

    @api.multi
    def Create_landed_cost(self):
        landed_cost = self.env['stock.landed.cost']
        landed_cost_line = self.env['stock.landed.cost.lines']
        account_journal = self.env['account.journal'].search([('type', '=', 'general')], limit=1)
        product_ids = self.env['product.product']
        product_obj=product_ids.search([('name', 'like', 'Freight')])
        landed_id = landed_cost.create({
            'date': fields.date.today(),
            'account_journal_id': account_journal.id,
            'picking_ids': [(6, 0, [self.id])],
        })
        landed_cost_line.create({
            'cost_id': landed_id.id,
            'product_id': product_obj.id,
            'split_method': 'by_current_cost_price',
            'price_unit': self.supplier_freight,
        })
        self.landed_cost_id = landed_id.id
        self.is_landed = True
        return {
                'type': 'ir.actions.act_window',
                'name': _('Landed Cost'),
                'res_model': 'stock.landed.cost',
                'res_id': landed_id.id,
                'view_type': 'form',
                'view_mode': 'form',
                'target': 'current',
              }

    @api.multi
    def Create_Transporter_Bill(self):
        product_ids = self.env['product.product']
        product_obj=product_ids.search([('name', 'like', 'Freight')])
        account_invoice_id = self.env['account.invoice']
        account_invoice_line_id = self.env['account.invoice.line']
        total = 0.0
        if product_obj:
            product_id = product_obj
        else:
            product_id = product_ids.create({
                'name': 'Freight',
                'type': 'product',
                'categ_id': 1,
            })
        for rec in self:
            total = sum(line.product_uom_qty for line in rec.move_lines)
        account_obj = account_invoice_id.create({
            'partner_id': self.Transporter_id.id,
            'journal_id': self.env['account.journal'].search([('type', '=', 'purchase')])[0].id,
            'name': self.bill_reference,
            'type': 'in_invoice',
            'transporter': True,
        })
        account_invoice_line_id.create({
            'invoice_id': account_obj.id,
            'product_id': product_id.id,
            'name': product_id.name,
            'quantity': 1,
            'price_unit': self.supplier_freight * total if self.freight_type == 'per_ton' else self.supplier_freight,
            'account_id': product_id.property_account_expense_id.id if product_id.property_account_expense_id else product_id.categ_id.property_stock_account_input_categ_id.id,
        })
        self.transporter_account_id = account_obj.id
        self.is_bill = True
        return {
                'type': 'ir.actions.act_window',
                'name': _('vendor bill'),
                'res_model': 'account.invoice',
                'res_id': account_obj.id,
                'view_type': 'form',
                'view_mode': 'form',
                'target': 'current',
              }

